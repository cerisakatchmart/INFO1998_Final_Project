"""Baselines, models, metrics, expanding-window CV, and a bootstrap over items."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor


# ---------- metrics ----------
def mae(y, p) -> float:
    return float(np.mean(np.abs(np.asarray(y) - np.asarray(p))))


def rmse(y, p) -> float:
    return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))


def wape(y, p) -> float:
    y = np.asarray(y)
    return float(np.abs(y - np.asarray(p)).sum() / max(y.sum(), 1e-9))


def score(y, p) -> dict[str, float]:
    return {"MAE": mae(y, p), "RMSE": rmse(y, p), "WAPE": wape(y, p)}


# ---------- baselines ----------
def naive_last_week(df: pd.DataFrame) -> np.ndarray:
    return df["lag_1"].to_numpy()


def moving_avg_4w(df: pd.DataFrame) -> np.ndarray:
    return df["roll_mean_4"].to_numpy()


# ---------- models ----------
def make_model(categorical_cols: list[str] | None = None, seed: int = 0) -> HistGradientBoostingRegressor:
    return HistGradientBoostingRegressor(
        loss="poisson", max_iter=300, learning_rate=0.05, max_leaf_nodes=15,
        min_samples_leaf=20, l2_regularization=1.0, random_state=seed,
        categorical_features="from_dtype" if categorical_cols else None,
    )


def fit_predict(train: pd.DataFrame, test: pd.DataFrame, cols: list[str], seed: int = 0) -> np.ndarray:
    cats = [c for c in cols if str(train[c].dtype) == "category"]
    model = make_model(cats, seed)
    model.fit(train[cols], train["target"])
    return np.clip(model.predict(test[cols]), 0, None)


# ---------- validation ----------
def time_split(df: pd.DataFrame, test_weeks: int):
    """Last `test_weeks` distinct weeks are the test set. A gap of one week is dropped from
    training because the final training row's target (t+1) would overlap the test period."""
    weeks = np.sort(df["week"].unique())
    cutoff = weeks[-test_weeks]
    train = df[df["week"] < cutoff - np.timedelta64(7, "D")]
    test = df[df["week"] >= cutoff]
    return train, test


def expanding_window_cv(df: pd.DataFrame, cols: list[str], n_splits: int = 4, fold_weeks: int = 6,
                        seed: int = 0) -> pd.DataFrame:
    """Expanding-window CV over weeks. Each fold trains on all earlier weeks, tests on the next block."""
    weeks = np.sort(df["week"].unique())
    rows = []
    for k in range(n_splits):
        end = len(weeks) - (n_splits - 1 - k) * fold_weeks
        start = end - fold_weeks
        test_weeks = weeks[start:end]
        train = df[df["week"] < weeks[start] - np.timedelta64(7, "D")]
        test = df[df["week"].isin(test_weeks)]
        if len(train) == 0 or len(test) == 0:
            continue
        p = fit_predict(train, test, cols, seed)
        rows.append({"fold": k, **score(test["target"], p)})
    return pd.DataFrame(rows)


def bootstrap_mae_diff(test: pd.DataFrame, pred_a: np.ndarray, pred_b: np.ndarray,
                       n_boot: int = 1000, seed: int = 0) -> dict[str, float]:
    """Resample ITEMS (not rows) to get a CI for MAE(a) - MAE(b). Negative => a is better."""
    rng = np.random.default_rng(seed)
    err = pd.DataFrame({
        "item_id": test["item_id"].to_numpy(),
        "ea": np.abs(test["target"].to_numpy() - pred_a),
        "eb": np.abs(test["target"].to_numpy() - pred_b),
    })
    per_item = err.groupby("item_id").agg(ea=("ea", "sum"), eb=("eb", "sum"), n=("ea", "size"))
    ea, eb, n = per_item["ea"].to_numpy(), per_item["eb"].to_numpy(), per_item["n"].to_numpy()
    m = len(per_item)
    diffs = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, m, m)
        diffs[b] = (ea[idx].sum() - eb[idx].sum()) / n[idx].sum()
    point = (ea.sum() - eb.sum()) / n.sum()
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    return {"diff": float(point), "ci_low": float(lo), "ci_high": float(hi)}
