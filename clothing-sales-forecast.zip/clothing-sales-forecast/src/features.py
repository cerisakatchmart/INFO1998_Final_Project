"""Feature engineering. Features at week t use only data up to the end of week t;
the target is units sold in week t+1."""
from __future__ import annotations

import numpy as np
import pandas as pd

LAG_FEATURES = [
    "lag_1", "lag_2", "lag_3", "lag_4", "roll_mean_4", "roll_mean_8", "roll_std_4",
]
PRICE_FEATURES = ["price", "price_change_pct", "discount_vs_avg"]
AGE_FEATURES = ["age_weeks"]
SEASON_FEATURES = ["woy_sin", "woy_cos"]


def add_features(panel: pd.DataFrame, attribute_cols: list[str] | None = None) -> pd.DataFrame:
    df = panel.sort_values(["item_id", "week"]).copy()
    g = df.groupby("item_id")["units"]

    # --- recent sales ---
    for k in range(1, 5):
        df[f"lag_{k}"] = g.shift(k - 1)  # lag_1 = this week's units
    df["roll_mean_4"] = g.transform(lambda s: s.rolling(4, min_periods=1).mean())
    df["roll_mean_8"] = g.transform(lambda s: s.rolling(8, min_periods=1).mean())
    df["roll_std_4"] = g.transform(lambda s: s.rolling(4, min_periods=2).std()).fillna(0)
    for k in range(2, 5):  # early-life weeks: fall back to earliest known value
        df[f"lag_{k}"] = df[f"lag_{k}"].fillna(df["lag_1"])

    # --- price ---
    gp = df.groupby("item_id")["price"]
    prev_price = gp.shift(1)
    df["price_change_pct"] = ((df["price"] - prev_price) / prev_price).fillna(0)
    hist_avg = gp.transform(lambda s: s.expanding().mean())  # only past + current
    df["discount_vs_avg"] = (hist_avg - df["price"]) / hist_avg

    # --- age and seasonality ---
    df["age_weeks"] = (df["week"] - df["launch_week"]).dt.days // 7
    woy = df["week"].dt.isocalendar().week.astype(int)
    df["woy_sin"] = np.sin(2 * np.pi * woy / 52)
    df["woy_cos"] = np.cos(2 * np.pi * woy / 52)

    # --- target: next week's units ---
    df["target"] = g.shift(-1)

    if attribute_cols:
        for c in attribute_cols:
            df[c] = df[c].astype("category")
    return df


def feature_sets(attribute_cols: list[str] | None = None) -> dict[str, list[str]]:
    attribute_cols = attribute_cols or []
    return {
        "lag_only": list(LAG_FEATURES),
        "full": LAG_FEATURES + PRICE_FEATURES + AGE_FEATURES + SEASON_FEATURES + attribute_cols,
    }
