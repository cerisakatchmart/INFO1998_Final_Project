"""Run the full comparison: baselines vs lag-only model vs full model.

    python -m src.run_experiment --demo
    python -m src.run_experiment --transactions data/raw/transactions.csv --attributes data/raw/items.csv
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from .data import build_weekly_panel, make_synthetic_panel
from .features import add_features, feature_sets
from .models import (bootstrap_mae_diff, expanding_window_cv, fit_predict, moving_avg_4w,
                     naive_last_week, score, time_split)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true", help="use synthetic data (pipeline smoke test only)")
    ap.add_argument("--transactions")
    ap.add_argument("--attributes")
    ap.add_argument("--item-col", default="item_id")
    ap.add_argument("--date-col", default="date")
    ap.add_argument("--price-col", default="price")
    ap.add_argument("--qty-col", default="quantity")
    ap.add_argument("--test-weeks", type=int, default=10)
    ap.add_argument("--out", default="results")
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    if args.demo:
        panel = make_synthetic_panel()
        print("NOTE: using SYNTHETIC data. Do not report these numbers.")
    else:
        if not args.transactions:
            ap.error("provide --transactions (or use --demo)")
        tx = pd.read_csv(args.transactions)
        attrs = pd.read_csv(args.attributes) if args.attributes else None
        panel = build_weekly_panel(tx, attrs, args.item_col, args.date_col, args.price_col, args.qty_col)
        Path("data/processed").mkdir(parents=True, exist_ok=True)
        panel.to_csv("data/processed/weekly_panel.csv", index=False)

    base_cols = {"item_id", "week", "units", "price", "launch_week"}
    attribute_cols = [c for c in panel.columns if c not in base_cols]
    df = add_features(panel, attribute_cols)
    df = df.dropna(subset=["target"])  # last week of each item has no next-week target

    sets = feature_sets(attribute_cols)
    train, test = time_split(df, args.test_weeks)
    print(f"train rows: {len(train):,}  test rows: {len(test):,}  items: {df['item_id'].nunique():,}")

    preds = {
        "naive_last_week": naive_last_week(test),
        "moving_avg_4w": moving_avg_4w(test),
        "model_lag_only": fit_predict(train, test, sets["lag_only"]),
        "model_full": fit_predict(train, test, sets["full"]),
    }
    metrics = pd.DataFrame({name: score(test["target"], p) for name, p in preds.items()}).T
    metrics.index.name = "forecaster"
    metrics.round(4).to_csv(out / "metrics.csv")
    print("\nTest-set metrics (lower is better):")
    print(metrics.round(3))

    print("\nExpanding-window CV (MAE per fold):")
    cv_rows = {}
    for name in ("lag_only", "full"):
        cv = expanding_window_cv(df, sets[name])
        cv_rows[name] = cv["MAE"].mean()
        print(f"  {name}: mean MAE {cv['MAE'].mean():.3f}  folds {cv['MAE'].round(2).tolist()}")

    diff = bootstrap_mae_diff(test, preds["model_full"], preds["model_lag_only"])
    verdict = ("full model has lower MAE" if diff["ci_high"] < 0 else
               "lag-only model has lower MAE" if diff["ci_low"] > 0 else
               "no clear difference (CI includes 0)")
    text = (f"MAE(full) - MAE(lag_only) = {diff['diff']:.3f} "
            f"(95% bootstrap CI over items: {diff['ci_low']:.3f} to {diff['ci_high']:.3f}) -> {verdict}\n")
    (out / "mae_difference.txt").write_text(text)
    print("\n" + text)

    ax = metrics["MAE"].plot.bar(rot=15, figsize=(7, 4), color="#4C78A8")
    ax.set_ylabel("Test MAE (units / item-week)")
    ax.set_title("Next-week sales forecast error by forecaster")
    plt.tight_layout()
    plt.savefig(out / "error_by_model.png", dpi=150)


if __name__ == "__main__":
    main()
