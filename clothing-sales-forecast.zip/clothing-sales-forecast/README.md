# Predicting Next-Week Sales of Clothing Items

This is the repository for our final project in INFO1998 (Cornell Data Science).

## Hypothesis

A product's recent sales, age, price changes, and attributes together predict its
next-week sales more accurately than its recent sales alone.

## Research Question

Is a predictive model better at forecasting next-week sales than basic trend baselines alone?

## Problem Type

Supervised **regression**. For every (item, week) pair we predict the number of units
sold in the *following* week.

## Approach

We compare four forecasters on the same held-out, **time-ordered** test period:

| Name | What it uses |
|---|---|
| `naive_last_week` | Next week = this week (baseline) |
| `moving_avg_4w` | Next week = mean of the last 4 weeks (baseline) |
| `model_lag_only` | Gradient boosting trained on recent sales only |
| `model_full` | Same model, plus price, price changes, item age, attributes, seasonality |

The key comparison for the hypothesis is `model_full` vs `model_lag_only` (same algorithm,
only the feature set differs). Comparing both against the baselines answers the research question.

### Features (see `src/features.py`)

- **Recent sales:** lags 1-4, rolling means (4 and 8 weeks), rolling std
- **Price:** current price, week-over-week price change, discount vs. item's historical average price
- **Age:** weeks since the item launched
- **Attributes:** category, color, etc. (one-hot / native categorical)
- **Seasonality:** week-of-year as sine/cosine

All features at week *t* only use information available at the end of week *t*. The target is units sold in week *t+1*.

### Validation

- Time-based train/test split (the last N weeks are the test set; no shuffling)
- Expanding-window cross-validation (`TimeSeriesSplit` over weeks) for model selection
- Bootstrap over items for a confidence interval on the MAE difference between `model_full` and `model_lag_only`

Metrics: MAE, RMSE, and WAPE (sum of absolute errors / sum of actual units).

## Repository Layout

```
clothing-sales-forecast/
├── README.md
├── requirements.txt
├── .gitignore
├── data/
│   ├── raw/            # put the downloaded dataset here (not committed)
│   └── processed/      # weekly panel written by the pipeline (not committed)
├── notebooks/          # exploration + final write-up notebook
├── results/            # metrics tables and figures
└── src/
    ├── prepare_hm.py   # H&M-specific: shrink raw Kaggle files
    ├── data.py         # load transactions -> weekly panel; synthetic demo data
    ├── features.py     # feature engineering
    ├── models.py       # baselines, models, metrics, CV, bootstrap
    └── run_experiment.py
```

## Quick Start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 1) Smoke test on synthetic data (no download needed)
python -m src.run_experiment --demo

# 2) Run on the H&M data (see "Dataset: H&M on Kaggle")
python -m src.prepare_hm            # shrinks 31M rows -> top 2,000 articles, weekly
python -m src.run_experiment \
    --transactions data/processed/hm_weekly_transactions.csv \
    --attributes data/processed/hm_items.csv
```

Outputs are written to `results/` (`metrics.csv`, `mae_difference.txt`, `error_by_model.png`).

> **Note:** `--demo` runs on *synthetic* data generated for testing the pipeline. Its numbers say
> nothing about real clothing sales and must not be reported in the final write-up.

## Dataset: H&M on Kaggle

[H&M Personalized Fashion Recommendations](https://www.kaggle.com/competitions/h-and-m-personalized-fashion-recommendations/overview)
is a recommendation competition, but its purchase history works for sales forecasting once
we count units per article per week.

**Download** (needs a Kaggle account; you must join the competition and accept its rules first,
and should read them to confirm how the data may be used):

```bash
pip install kaggle   # then put your API token at ~/.kaggle/kaggle.json
kaggle competitions download -c h-and-m-personalized-fashion-recommendations \
    -f transactions_train.csv -p data/raw   # and again with -f articles.csv
# unzip the downloaded files into data/raw/
```

**Files we use:**

| file | columns we use |
|---|---|
| `transactions_train.csv` | `t_dat`, `article_id`, `price` (one row = one unit sold; `customer_id` and `sales_channel_id` are ignored) |
| `articles.csv` | `article_id`, `product_type_name`, `product_group_name`, `garment_group_name`, `perceived_colour_master_name`, `index_group_name` |

`customers.csv` is not used: we forecast item sales, not customer behavior.

**What `src/prepare_hm.py` does and its consequences (mention these in the write-up):**

- Aggregates to units per `article_id` per week, reading the large file in chunks.
- Keeps the 2,000 best-selling articles that sold in at least 26 different weeks. This drops
  slow-moving items, so results apply to *popular* articles, not the whole catalog.
- Drops articles already selling in the first 4 weeks of the data, because their true launch
  date is unknown and "age" would be wrong. This biases the sample toward newer items.
  (`--keep-censored` keeps them.)
- Kaggle's `price` is a scaled value, not dollars. We only use relative price changes,
  so this is fine, but do not call it a dollar price.
- Our environment could not download the data, so `prepare_hm.py` has been tested on a small
  fake file in the same format, not on the real files. Expect to debug column dtypes or
  memory use on your first real run (lower `chunksize` in the script if RAM is tight).

## Using a Different Dataset

If you pick another dataset (ideas: [Kaggle](https://www.kaggle.com/datasets),
[Data.gov](https://www.data.gov/), [UCI](http://archive.ics.uci.edu/ml/index.php),
[Data Hub](https://datahub.io/collections)), `run_experiment` accepts any file in this format:

**Transactions file** (one row per sale or per item-day):

| column | meaning |
|---|---|
| `item_id` | product identifier |
| `date` | date of sale |
| `price` | unit price paid |
| `quantity` | units sold (defaults to 1 per row if the column is absent) |

**Attributes file** (one row per item; any extra columns are treated as attributes):

| column | meaning |
|---|---|
| `item_id` | product identifier |
| `category`, `color`, ... | descriptive attributes |

If your column names differ, pass them with `--item-col`, `--date-col`, `--price-col`,
`--qty-col`. Once an item has its first sale, weeks without sales count as 0 units, through the
last week in the data.

## Project Milestones (from the course)

- [ ] Week 1: Find a group
- [ ] Week 2: Find a dataset and define the question
- [ ] Week 3: Explore and manipulate the data; draft hypothesis
- [ ] Week 4: Clean, visualize, feature engineering; finalize hypothesis
- [ ] Week 5: Visualizations
- [ ] Week 6: Choose models (regression); mid-semester check-in
- [ ] Week 7: Model construction; consider cross validation
- [ ] Week 8: Finish models; extra validation; revisit visualizations
- [ ] Week 9: Final touches; write-up interpreting results against the hypothesis
- [ ] Week 10: Turn in

## Academic Integrity

We do not copy code from other projects built on the same dataset. All code in this repo
was written (or adapted and understood) by our group.

## Team

- _Add names and NetIDs here_
